package com.nihar.mandal.mymavenspringbootproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyMavenSpringBootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyMavenSpringBootProjectApplication.class, args);
	}

}
